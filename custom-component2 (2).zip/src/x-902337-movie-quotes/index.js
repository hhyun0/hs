import {createCustomElement} from '@servicenow/ui-core';
import snabbdom from '@servicenow/ui-renderer-snabbdom';
import styles from './styles.scss';

const view = (state, {updateState}) => {
	return (
		<div>lddddddddddd</div>
	);
};

createCustomElement('x-902337-movie-quotes', {
	renderer: {type: snabbdom},
	view,
	styles
});
