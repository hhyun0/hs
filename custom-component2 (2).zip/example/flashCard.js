import '../src/flash-card-example';

const el = document.createElement('DIV');
document.body.appendChild(el);

el.innerHTML = `		
    <example-card-list></example-card-list> 
`;
