import '../src/agent-assist-example';

const el = document.createElement('DIV');
document.body.appendChild(el);

el.innerHTML = `		
    <div style="height: 800px;">
        <example-agent-assist></example-agent-assist>
    </div>
`;
