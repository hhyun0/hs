import '../src/task-board-example';

const el = document.createElement('DIV');
document.body.appendChild(el);

el.innerHTML = `		
    <example-task-board></example-task-board> 
`;
