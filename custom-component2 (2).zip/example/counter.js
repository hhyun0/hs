import '../src/counter-example';

const el = document.createElement('DIV');
document.body.appendChild(el);

el.innerHTML = `		
    <example-counter></example-counter> 
`;
