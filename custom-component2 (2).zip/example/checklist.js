import '../src/checklist-example';

const el = document.createElement('DIV');
document.body.appendChild(el);

el.innerHTML = `		
    <example-checklist></example-checklist> 
`;
