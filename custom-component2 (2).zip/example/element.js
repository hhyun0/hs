import '../src/x-902337-movie-quotes';

const el = document.createElement('DIV');
document.body.appendChild(el);

el.innerHTML = `		
<x-902337-movie-quotes></x-902337-movie-quotes>
`;
